var getElement = document.querySelector("#number");
var number = 3;
function increaseLikes(){
    number ++;
    getElement.innerText = number;
}